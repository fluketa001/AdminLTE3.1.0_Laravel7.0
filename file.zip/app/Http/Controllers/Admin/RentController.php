<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Validator;
use Redirect;
use Auth;
use File;
use App\Resident;
use App\Room;
use App\Rent;

class RentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth.user');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rents = Rent::all();
        return view('admin.rent.index')->with('data',$rents);
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $residents = Resident::leftJoin('rooms', 'residents.rooms_id', '=', 'rooms.id')
            ->select('*','residents.id')
            ->where('residents_status','1')
            ->get();
            // dd($residents);
        return view('admin.rent.add')->with('data',$residents);
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $validated = $request->validate([
            'rents_month' => 'string',
            'rents_datetime' => 'string',
            // 'rents_slip' => 'string',
            'rooms_id' => 'string',
            'residents_name' => 'string',
            'residents_telephone' => 'string',
            'residents_rent_price' => 'string',
            'residents_id' => 'string',
            'users_name' => 'string'
        ]);
        // dd($request->all());
        $room = Room::where('id',$validated['rooms_id'])->first();
        $rents_month = $validated['rents_month'].'-01';

        $date = date('Y-m-d_H-i-s');
        $picture_extension = $request->file('rents_slip')->getClientOriginalExtension();
        $picture = "slip_".$date.".".$picture_extension;
        $request->rents_slip->storeAs('/slip', $picture);
        $picture_url = Storage::url("slip_".$date.".".$picture_extension);

        $rents = Rent::create([
            'rents_month' => $rents_month,
            'rents_datetime' => $validated['rents_datetime'],
            'rents_slip' => $picture,
            'rooms_number' => $room->rooms_number,
            'rooms_house_number' => $room->rooms_house_number,
            'residents_name' => $validated['residents_name'],
            'residents_telephone' => $validated['residents_telephone'],
            'residents_rent_price' => $validated['residents_rent_price'],
            'residents_id' => $validated['residents_id'],
            'users_name' => $validated['users_name']
        ]);

        $ip = $_SERVER['REMOTE_ADDR'];
        $date = @date("d/m/Y H:i:s");
        $content = ' \n'.$date.'-->IP: '.$ip.'\n\t\t\t--> content:'.
                    'rents_month->: '.$rents_month.'\t\t rents_datetime->: '.$validated['rents_datetime'].'\t\t rents_slip->: '.$picture.
                    '\r\n rooms_number->: '.$room->rooms_number.'\t\t rooms_house_number->: '.$room->rooms_house_number.'\t\t residents_name->: '.$validated['residents_name'].
                    '\r\n residents_telephone->: '.$validated['residents_telephone'].'\t\t residents_rent_price->: '.$validated['residents_rent_price'].'\t\t residents_id->: '.$validated['residents_id'].
                    '\r\n users_name->: '.$validated['users_name'];

        // save file SMS Kasikorn Bank
        File::makeDirectory("rent/".date("Ymd"), $mode = 0777, true, true);
        $random = rand(123456,999999);
        $objFopen= fopen("rent/".date("Ymd")."/".date("His_").$random.".log","w+");
        $pathFile = "rent/".date("Ymd")."/".date("His_").$random.".log";
        $result=fwrite($objFopen,json_encode($content));
        fclose($objFopen);

        if($rents->id){
            return redirect()->route('rents')->with('message','success');
        }else{
            return redirect()->back()->with('message','error');
        }
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $rents = Rent::where('id',$id)->first();
            // dd($rents);
        return view('admin.rent.edit')->with('data',$rents);
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // dd($request->all());
        $validated = $request->validate([
            'id' => 'string',
            'rents_month' => 'string',
            'rents_datetime' => 'string',
            'residents_rent_price' => 'string',
            'users_name' => 'string'
        ]);
        // dd($request->all());
        $rents_month = $validated['rents_month'].'-01';

        if($request->file('rents_slip')){
            $rent = Rent::where('id',$validated['id'])->first();
            $image_path = "storage/slip/".$rent->rents_slip;  // path image
            if (file_exists("storage/slip")) {
                unlink($image_path);
            }

            $date = date('Y-m-d_H-i-s');
            $picture_extension = $request->file('rents_slip')->getClientOriginalExtension();
            $picture = "slip_".$date.".".$picture_extension;
            $request->rents_slip->storeAs('/slip', $picture);
            $picture_url = Storage::url("slip_".$date.".".$picture_extension);
    
            $rents = Rent::where('id',$validated['id'])->update([
                'rents_month' => $rents_month,
                'rents_datetime' => $validated['rents_datetime'],
                'rents_slip' => $picture,
                'residents_rent_price' => $validated['residents_rent_price'],
                'users_name' => $validated['users_name']
            ]);
        }else{
            $picture = '';
            $rents = Rent::where('id',$validated['id'])->update([
                'rents_month' => $rents_month,
                'rents_datetime' => $validated['rents_datetime'],
                'residents_rent_price' => $validated['residents_rent_price'],
                'users_name' => $validated['users_name']
            ]);
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $date = @date("d/m/Y H:i:s");
        $content = ' \n'.$date.'-->IP: '.$ip.'\n\t\t\t--> content:'.
                    'rents_month->: '.$rents_month.'\t\t rents_datetime->: '.$validated['rents_datetime'].'\t\t rents_slip->: '.$picture.
                    '\r\n residents_rent_price->: '.$validated['residents_rent_price'].
                    '\r\n users_name->: '.$validated['users_name'];

        // save file SMS Kasikorn Bank
        File::makeDirectory("rent/".date("Ymd"), $mode = 0777, true, true);
        $random = rand(123456,999999);
        $objFopen= fopen("rent/".date("Ymd")."/".date("His_").$random."_update.log","w+");
        $pathFile = "rent/".date("Ymd")."/".date("His_").$random."_update.log";
        $result=fwrite($objFopen,json_encode($content));
        fclose($objFopen);

        if($rents){
            return redirect()->route('rents')->with('message','edit');
        }else{
            return redirect()->back()->with('message','error');
        }
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $rents = Rent::where('id',$id)->delete();
        if($rents){
            return redirect()->route('rents')->with('message','delete');
        }else{
            return redirect()->route('rents')->with('message','error');
        }
        //
    }
}
